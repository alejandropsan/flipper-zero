#pragma once

#include "../nfc_protocol_support_base.h"

extern const NfcProtocolSupportBase nfc_protocol_support_mf_classic;
